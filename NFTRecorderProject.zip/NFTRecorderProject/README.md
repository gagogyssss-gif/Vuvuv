# NFT Recorder (Android)

Deterministic Telegram collectible-gift renderer for Android.

What it does:
- accepts `https://t.me/nft/<slug>` or a raw slug;
- downloads the public Lottie animation from `nft.fragment.com`;
- renders one full animation loop frame-by-frame;
- encodes H.264 MP4 at 1920x1080, 60 FPS, ~20 Mbps;
- uses explicit EGL presentation timestamps (`1/60 s` per frame), so the device may render slowly while the final video remains smooth;
- saves to `Movies/NFTRecorder`.

Build with GitHub Actions:
1. Copy `nft-recorder/` and `.github/workflows/build-nft-recorder.yml` into the repository root.
2. Open Actions -> Build NFT Recorder APK -> Run workflow.
3. Download the `NFT-Recorder-1080p60` artifact.

Note: this is a first-build implementation intended for Android 8+ and optimized for the requested Android 15 device workflow. Some vendor H.264 encoders may reject 1920x1080@60 metadata even for offline rendering; if that happens, the encoder configuration needs a device-specific fallback while retaining 60 FPS timestamps.
