package com.vuvuv.nftrecorder;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Rect;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaCodecList;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.net.Uri;
import android.opengl.EGL14;
import android.opengl.EGLExt;
import android.opengl.GLES20;
import android.opengl.GLUtils;
import android.os.Build;
import android.provider.MediaStore;
import android.view.Surface;

import com.airbnb.lottie.LottieComposition;
import com.airbnb.lottie.LottieDrawable;

import java.io.File;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public final class H264LottieRenderer {
    public interface ProgressListener { void onProgress(int percent); }

    private static final int WIDTH = 1920;
    private static final int HEIGHT = 1080;
    private static final int FPS = 60;
    private static final int BITRATE = 20_000_000;
    private static final String MIME = MediaFormat.MIMETYPE_VIDEO_AVC;

    private final Context context;

    public H264LottieRenderer(Context context) {
        this.context = context.getApplicationContext();
    }

    public String render(LottieComposition composition, ProgressListener listener) throws Exception {
        File temp = new File(context.getCacheDir(), "nft-render-" + System.nanoTime() + ".mp4");
        MediaCodec codec = null;
        Surface codecSurface = null;
        EglEncoderSurface egl = null;
        MediaMuxer muxer = null;
        Bitmap bitmap = null;

        try {
            codec = createConfiguredEncoder();
            codecSurface = codec.createInputSurface();
            codec.start();

            egl = new EglEncoderSurface(codecSurface);
            muxer = new MediaMuxer(temp.getAbsolutePath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);

            EncoderDrain drain = new EncoderDrain(codec, muxer);
            LottieDrawable drawable = new LottieDrawable();
            drawable.setComposition(composition);

            Rect src = composition.getBounds();
            float scale = Math.min((float) WIDTH / src.width(), (float) HEIGHT / src.height());
            int drawW = Math.round(src.width() * scale);
            int drawH = Math.round(src.height() * scale);
            int left = (WIDTH - drawW) / 2;
            int top = (HEIGHT - drawH) / 2;
            drawable.setBounds(left, top, left + drawW, top + drawH);

            bitmap = Bitmap.createBitmap(WIDTH, HEIGHT, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(bitmap);

            float durationMs = composition.getDuration();
            int frameCount = Math.max(1, Math.round(durationMs / 1000f * FPS));

            for (int i = 0; i < frameCount; i++) {
                canvas.drawColor(Color.BLACK);
                float progress = frameCount <= 1 ? 0f : (float) i / (float) frameCount;
                drawable.setProgress(progress);
                drawable.draw(canvas);

                long ptsNs = i * 1_000_000_000L / FPS;
                egl.draw(bitmap, ptsNs);
                drain.drain(false);

                if (listener != null) {
                    listener.onProgress((i + 1) * 100 / frameCount);
                }
            }

            codec.signalEndOfInputStream();
            drain.drain(true);
            drain.finish();

            String displayName = "NFT_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()) + "_1080p60.mp4";
            saveToGallery(temp, displayName);
            return displayName;
        } finally {
            if (bitmap != null) bitmap.recycle();
            if (egl != null) egl.release();
            if (codecSurface != null) codecSurface.release();
            if (codec != null) {
                try { codec.stop(); } catch (Exception ignored) {}
                codec.release();
            }
            if (muxer != null) {
                try { muxer.release(); } catch (Exception ignored) {}
            }
            if (temp.exists()) temp.delete();
        }
    }


    private MediaCodec createConfiguredEncoder() throws Exception {
        Exception last = null;
        MediaCodecInfo[] infos = new MediaCodecList(MediaCodecList.ALL_CODECS).getCodecInfos();
        int[] declaredRates = new int[]{FPS, 30};

        for (int declaredRate : declaredRates) {
            for (MediaCodecInfo info : infos) {
                if (!info.isEncoder()) continue;
                boolean avc = false;
                for (String type : info.getSupportedTypes()) {
                    if (MIME.equalsIgnoreCase(type)) { avc = true; break; }
                }
                if (!avc) continue;

                MediaCodec candidate = null;
                try {
                    MediaCodecInfo.CodecCapabilities caps = info.getCapabilitiesForType(MIME);
                    boolean surface = false;
                    for (int cf : caps.colorFormats) {
                        if (cf == MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface) {
                            surface = true; break;
                        }
                    }
                    if (!surface || !caps.getVideoCapabilities().isSizeSupported(WIDTH, HEIGHT)) continue;

                    MediaFormat format = MediaFormat.createVideoFormat(MIME, WIDTH, HEIGHT);
                    format.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface);
                    format.setInteger(MediaFormat.KEY_BIT_RATE, BITRATE);
                    // Some low-end hardware codecs reject 1080p60 configuration even for offline encoding.
                    // If that happens, declare 30 here but still submit 60 unique frames with exact 1/60s PTS.
                    format.setInteger(MediaFormat.KEY_FRAME_RATE, declaredRate);
                    format.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1);
                    if (Build.VERSION.SDK_INT >= 23) format.setInteger(MediaFormat.KEY_PRIORITY, 1);

                    candidate = MediaCodec.createByCodecName(info.getName());
                    candidate.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
                    return candidate;
                } catch (Exception e) {
                    last = e;
                    if (candidate != null) {
                        try { candidate.release(); } catch (Exception ignored) {}
                    }
                }
            }
        }
        throw new Exception("No H.264 encoder accepted 1920x1080", last);
    }

    private void saveToGallery(File source, String displayName) throws Exception {
        ContentResolver resolver = context.getContentResolver();
        ContentValues values = new ContentValues();
        values.put(MediaStore.Video.Media.DISPLAY_NAME, displayName);
        values.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
        if (Build.VERSION.SDK_INT >= 29) {
            values.put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/NFTRecorder");
            values.put(MediaStore.Video.Media.IS_PENDING, 1);
        }

        Uri collection = Build.VERSION.SDK_INT >= 29
                ? MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                : MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
        Uri uri = resolver.insert(collection, values);
        if (uri == null) throw new Exception("MediaStore insert failed");

        try (FileInputStream in = new FileInputStream(source);
             OutputStream out = resolver.openOutputStream(uri, "w")) {
            if (out == null) throw new Exception("Cannot open MediaStore output");
            byte[] buffer = new byte[1024 * 1024];
            int n;
            while ((n = in.read(buffer)) > 0) out.write(buffer, 0, n);
        } catch (Exception e) {
            resolver.delete(uri, null, null);
            throw e;
        }

        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues done = new ContentValues();
            done.put(MediaStore.Video.Media.IS_PENDING, 0);
            resolver.update(uri, done, null, null);
        }
    }

    private static final class EncoderDrain {
        private final MediaCodec codec;
        private final MediaMuxer muxer;
        private final MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
        private int trackIndex = -1;
        private boolean muxerStarted = false;

        EncoderDrain(MediaCodec codec, MediaMuxer muxer) {
            this.codec = codec;
            this.muxer = muxer;
        }

        void drain(boolean end) throws Exception {
            while (true) {
                int index = codec.dequeueOutputBuffer(info, end ? 10_000 : 0);
                if (index == MediaCodec.INFO_TRY_AGAIN_LATER) {
                    if (!end) return;
                } else if (index == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    if (muxerStarted) throw new Exception("Encoder format changed twice");
                    trackIndex = muxer.addTrack(codec.getOutputFormat());
                    muxer.start();
                    muxerStarted = true;
                } else if (index >= 0) {
                    ByteBuffer data = codec.getOutputBuffer(index);
                    if (data == null) throw new Exception("Encoder returned null buffer");

                    if ((info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) {
                        info.size = 0;
                    }
                    if (info.size > 0) {
                        if (!muxerStarted) throw new Exception("Muxer not started");
                        data.position(info.offset);
                        data.limit(info.offset + info.size);
                        muxer.writeSampleData(trackIndex, data, info);
                    }
                    codec.releaseOutputBuffer(index, false);
                    if ((info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) return;
                }
            }
        }

        void finish() {
            if (muxerStarted) {
                try { muxer.stop(); } catch (Exception ignored) {}
                muxerStarted = false;
            }
        }
    }

    private static final class EglEncoderSurface {
        private static final int EGL_RECORDABLE_ANDROID = 0x3142;
        private final Surface windowSurface;
        private android.opengl.EGLDisplay display = EGL14.EGL_NO_DISPLAY;
        private android.opengl.EGLContext context = EGL14.EGL_NO_CONTEXT;
        private android.opengl.EGLSurface surface = EGL14.EGL_NO_SURFACE;

        private int program;
        private int texture;
        private int posLoc;
        private int texLoc;
        private int samplerLoc;
        private final FloatBuffer vertices;
        private final FloatBuffer texCoords;

        EglEncoderSurface(Surface windowSurface) throws Exception {
            this.windowSurface = windowSurface;
            vertices = buffer(new float[]{-1f,-1f, 1f,-1f, -1f,1f, 1f,1f});
            texCoords = buffer(new float[]{0f,1f, 1f,1f, 0f,0f, 1f,0f});
            setupEgl();
            setupGl();
        }

        private static FloatBuffer buffer(float[] values) {
            FloatBuffer b = ByteBuffer.allocateDirect(values.length * 4)
                    .order(ByteOrder.nativeOrder()).asFloatBuffer();
            b.put(values).position(0);
            return b;
        }

        private void setupEgl() throws Exception {
            display = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY);
            if (display == EGL14.EGL_NO_DISPLAY) throw new Exception("No EGL display");
            int[] version = new int[2];
            if (!EGL14.eglInitialize(display, version, 0, version, 1)) throw new Exception("eglInitialize failed");

            int[] attrs = {
                    EGL14.EGL_RED_SIZE, 8,
                    EGL14.EGL_GREEN_SIZE, 8,
                    EGL14.EGL_BLUE_SIZE, 8,
                    EGL14.EGL_ALPHA_SIZE, 8,
                    EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
                    EGL_RECORDABLE_ANDROID, 1,
                    EGL14.EGL_NONE
            };
            android.opengl.EGLConfig[] configs = new android.opengl.EGLConfig[1];
            int[] count = new int[1];
            if (!EGL14.eglChooseConfig(display, attrs, 0, configs, 0, 1, count, 0) || count[0] == 0) {
                throw new Exception("No recordable EGL config");
            }

            int[] ctxAttrs = {EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE};
            context = EGL14.eglCreateContext(display, configs[0], EGL14.EGL_NO_CONTEXT, ctxAttrs, 0);
            if (context == null || context == EGL14.EGL_NO_CONTEXT) throw new Exception("eglCreateContext failed");

            int[] surfAttrs = {EGL14.EGL_NONE};
            surface = EGL14.eglCreateWindowSurface(display, configs[0], windowSurface, surfAttrs, 0);
            if (surface == null || surface == EGL14.EGL_NO_SURFACE) throw new Exception("eglCreateWindowSurface failed");
            if (!EGL14.eglMakeCurrent(display, surface, surface, context)) throw new Exception("eglMakeCurrent failed");
        }

        private void setupGl() throws Exception {
            String vs = "attribute vec4 aPosition; attribute vec2 aTexCoord; varying vec2 vTexCoord;" +
                    "void main(){ gl_Position=aPosition; vTexCoord=aTexCoord; }";
            String fs = "precision mediump float; varying vec2 vTexCoord; uniform sampler2D uTexture;" +
                    "void main(){ gl_FragColor=texture2D(uTexture,vTexCoord); }";
            program = link(vs, fs);
            posLoc = GLES20.glGetAttribLocation(program, "aPosition");
            texLoc = GLES20.glGetAttribLocation(program, "aTexCoord");
            samplerLoc = GLES20.glGetUniformLocation(program, "uTexture");

            int[] tex = new int[1];
            GLES20.glGenTextures(1, tex, 0);
            texture = tex[0];
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texture);
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR);
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR);
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE);
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE);
        }

        void draw(Bitmap bitmap, long presentationTimeNs) {
            GLES20.glViewport(0, 0, WIDTH, HEIGHT);
            GLES20.glUseProgram(program);
            GLES20.glActiveTexture(GLES20.GL_TEXTURE0);
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texture);
            GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bitmap, 0);
            GLES20.glUniform1i(samplerLoc, 0);

            vertices.position(0);
            texCoords.position(0);
            GLES20.glEnableVertexAttribArray(posLoc);
            GLES20.glVertexAttribPointer(posLoc, 2, GLES20.GL_FLOAT, false, 0, vertices);
            GLES20.glEnableVertexAttribArray(texLoc);
            GLES20.glVertexAttribPointer(texLoc, 2, GLES20.GL_FLOAT, false, 0, texCoords);
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4);
            GLES20.glDisableVertexAttribArray(posLoc);
            GLES20.glDisableVertexAttribArray(texLoc);

            EGLExt.eglPresentationTimeANDROID(display, surface, presentationTimeNs);
            EGL14.eglSwapBuffers(display, surface);
        }

        private static int compile(int type, String src) throws Exception {
            int shader = GLES20.glCreateShader(type);
            GLES20.glShaderSource(shader, src);
            GLES20.glCompileShader(shader);
            int[] ok = new int[1];
            GLES20.glGetShaderiv(shader, GLES20.GL_COMPILE_STATUS, ok, 0);
            if (ok[0] == 0) {
                String log = GLES20.glGetShaderInfoLog(shader);
                GLES20.glDeleteShader(shader);
                throw new Exception("Shader compile failed: " + log);
            }
            return shader;
        }

        private static int link(String vs, String fs) throws Exception {
            int v = compile(GLES20.GL_VERTEX_SHADER, vs);
            int f = compile(GLES20.GL_FRAGMENT_SHADER, fs);
            int p = GLES20.glCreateProgram();
            GLES20.glAttachShader(p, v);
            GLES20.glAttachShader(p, f);
            GLES20.glLinkProgram(p);
            int[] ok = new int[1];
            GLES20.glGetProgramiv(p, GLES20.GL_LINK_STATUS, ok, 0);
            GLES20.glDeleteShader(v);
            GLES20.glDeleteShader(f);
            if (ok[0] == 0) {
                String log = GLES20.glGetProgramInfoLog(p);
                GLES20.glDeleteProgram(p);
                throw new Exception("Program link failed: " + log);
            }
            return p;
        }

        void release() {
            if (display != EGL14.EGL_NO_DISPLAY) {
                EGL14.eglMakeCurrent(display, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT);
                if (surface != EGL14.EGL_NO_SURFACE) EGL14.eglDestroySurface(display, surface);
                if (context != EGL14.EGL_NO_CONTEXT) EGL14.eglDestroyContext(display, context);
                EGL14.eglReleaseThread();
                EGL14.eglTerminate(display);
            }
            display = EGL14.EGL_NO_DISPLAY;
            context = EGL14.EGL_NO_CONTEXT;
            surface = EGL14.EGL_NO_SURFACE;
        }
    }
}
