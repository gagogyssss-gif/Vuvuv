package com.vuvuv.nftrecorder;

import android.app.Activity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.airbnb.lottie.LottieAnimationView;
import com.airbnb.lottie.LottieComposition;
import com.airbnb.lottie.LottieCompositionFactory;
import com.airbnb.lottie.LottieDrawable;
import com.airbnb.lottie.LottieResult;

import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private EditText input;
    private Button record;
    private TextView status;
    private LottieAnimationView preview;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        int pad = dp(16);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);
        root.setGravity(Gravity.CENTER_HORIZONTAL);

        TextView title = new TextView(this);
        title.setText("NFT Recorder — 1080p60");
        title.setTextSize(22);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        input = new EditText(this);
        input.setSingleLine(true);
        input.setHint("https://t.me/nft/PlushPepe-1");
        LinearLayout.LayoutParams inputLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        inputLp.topMargin = dp(12);
        root.addView(input, inputLp);

        preview = new LottieAnimationView(this);
        preview.setRepeatCount(LottieDrawable.INFINITE);
        LinearLayout.LayoutParams previewLp = new LinearLayout.LayoutParams(dp(280), dp(280));
        previewLp.topMargin = dp(12);
        root.addView(preview, previewLp);

        record = new Button(this);
        record.setText("REC 1080p / 60 FPS");
        LinearLayout.LayoutParams buttonLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        buttonLp.topMargin = dp(12);
        root.addView(record, buttonLp);

        status = new TextView(this);
        status.setText("Вставь ссылку на Telegram NFT и нажми REC.");
        status.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams statusLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        statusLp.topMargin = dp(12);
        root.addView(status, statusLp);

        setContentView(root);
        record.setOnClickListener(v -> startRender());
    }

    private void startRender() {
        String slug = extractSlug(input.getText().toString().trim());
        if (slug == null || slug.isEmpty()) {
            status.setText("Нужна ссылка t.me/nft/... или slug подарка.");
            return;
        }

        record.setEnabled(false);
        status.setText("Загружаю анимацию…");

        worker.submit(() -> {
            try {
                LottieComposition composition = loadComposition(slug);
                runOnUiThread(() -> {
                    preview.setComposition(composition);
                    preview.playAnimation();
                    status.setText("Рендерю 1920×1080 @ 60 FPS… телефон может лагать — это нормально.");
                });

                H264LottieRenderer renderer = new H264LottieRenderer(this);
                String savedName = renderer.render(composition, progress -> {
                    if (progress % 5 == 0 || progress == 100) {
                        runOnUiThread(() -> status.setText("Рендер: " + progress + "%"));
                    }
                });

                runOnUiThread(() -> {
                    status.setText("Готово: " + savedName + "\nСохранено в Movies/NFTRecorder");
                    record.setEnabled(true);
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    status.setText("Ошибка: " + (e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage()));
                    record.setEnabled(true);
                });
            }
        });
    }

    private LottieComposition loadComposition(String slug) throws Exception {
        String[] candidates = new String[] {
                "https://nft.fragment.com/gift/" + slug + ".lottie.json",
                "https://nft.fragment.com/gift/" + slug.toLowerCase(Locale.ROOT) + ".lottie.json"
        };

        Exception last = null;
        for (String url : candidates) {
            LottieResult<LottieComposition> result = LottieCompositionFactory.fromUrlSync(this, url, null);
            if (result.getValue() != null) return result.getValue();
            if (result.getException() != null) last = result.getException();
        }
        throw new Exception("Не удалось получить Lottie с nft.fragment.com", last);
    }

    private static String extractSlug(String value) {
        if (value == null) return null;
        value = value.trim();
        int idx = value.indexOf("t.me/nft/");
        if (idx >= 0) {
            value = value.substring(idx + "t.me/nft/".length());
        }
        int cut = value.length();
        for (char c : new char[]{'?', '#', '/'}) {
            int p = value.indexOf(c);
            if (p >= 0 && p < cut) cut = p;
        }
        value = value.substring(0, cut).trim();
        return value.matches("[A-Za-z0-9_-]+") ? value : null;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onDestroy() {
        worker.shutdownNow();
        super.onDestroy();
    }
}
